/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   arch_64.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jmancero <jmancero@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/04/25 13:46:16 by jmancero          #+#    #+#             */
/*   Updated: 2014/04/25 18:26:59 by jmancero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "nm.h"
#include <stdio.h>

void	print_output(int nsyms, int symoff, int stroff, char *ptr)
{
	int i;
	char *stringtable;
	struct nlist_64 *el;

	el = (void *)(ptr + symoff);
	stringtable = ptr + stroff;
	i = 0;
	ft_putstr("-------------------------------------------------------------");
	while (i < nsyms)
	{
		printf("%s\n", stringtable + el[i].n_un.n_strx);
		i++;
	}
}

void	handle_64(char *ptr)
{
	int						n_cmds;
	struct mach_header_64	*header;
	struct load_command		*lc;
	int						i;
	struct	symtab_command	*sym;

	i = 0;
	ft_printf("ok\n");
	header = (struct mach_header_64 *) ptr;
	lc = (struct load_command *)((char *)ptr + sizeof(*header));
	n_cmds = header->ncmds;
	while (i < n_cmds)
	{
		if (lc->cmd == LC_SYMTAB)
		{
			sym = (struct symtab_command *) lc;
			print_output(sym->nsyms, sym->symoff, sym->stroff, ptr);
			break ;
		}
		lc = (struct load_command *)((char *)lc + lc->cmdsize);
		i++;
	}
}
