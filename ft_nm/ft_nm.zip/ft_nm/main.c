/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jmancero <jmancero@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/04/22 18:32:38 by jmancero          #+#    #+#             */
/*   Updated: 2014/04/25 17:18:45 by jmancero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "nm.h"

void	nm(char *ptr)
{
	unsigned int magic_number;

	magic_number = *(int *) ptr;
	if (magic_number == MH_MAGIC_64)
		handle_64(ptr);
}

char	*open_file(char *file)
{
	int			fd;
	struct stat	buff;
	void		*ptr;
	int			len;

	if ((fd = open(file, O_RDONLY)) < 0)
	{
		ft_puterr("fail to open file\n");
		return (NULL);
	}
	if (fstat(fd, &buff) < 0)
	{
		ft_puterr("stat fail");
		return (NULL);
	}
	len =  buff.st_size;
	if ((ptr = mmap(0, len, PROT_READ, MAP_PRIVATE,fd, 0)) == MAP_FAILED)
	{
		ft_puterr("mmap fail");
		return (NULL);
	}
	return (ptr);
}


int	main (int ac, char **av)
{
	char	*ptr;

	(void) ac;
	ptr = open_file(av[1]);
	if (ptr != NULL)
	{
		nm(ptr);
	}
}
