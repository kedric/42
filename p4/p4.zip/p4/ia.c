/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ia.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alegay <alegay@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/03/08 08:23:51 by jmancero          #+#    #+#             */
/*   Updated: 2014/03/08 18:36:55 by alegay           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "puissance.h"



int		ft_vs(int player)
{
	if (player == BLUE)
		return (RED);
	return (BLUE);
}

int		mini_max(int player, int deph, t_game *game)
{
	int	check;
	int	max;
	int	tmp;
	int	x;
	int y;

	check = check_winner();
	max = 0;
	tmp = 0;
	if (check == game->player_in)
		return (1);
	else if (check == ft_vs(game->player_in))
		return (-1);
	else if (check == EGAL || deph == 0)
		return (0);
	x = 0;
	while (x < game->max_x)
	{
		y = 0;
		while (y < game->max_y)
		{
			if (!game->grid[x][y] && valid_position(game, x, y))
			{
				game->grid[x][y] = player;
				tmp += mini_max(ft_vs(player), deph - 1, game);
				max = tmp;
				game->grid[x][y] = 0;
			}
			y++;
		}
		x++;
	}
	return (max);
}

int		valid_position(t_game *game, int x, int y)
{
	if (game->grid[x][y] == 0)
	{
		if (x == game->max_x - 1)
			return (1);
		if (y < game->max_y && game->grid[x + 1][y] != 0)
			return (1);
	}
	return (0);
}


void	ia(int player, t_game *game)
{
	int x_tmp;
	int	y_tmp;
	int	tmp;
	int	max;
	int	x;
	int	y;

	tmp = 0;
	max = -1000000;
	x = 0;
	y = 0;
	x_tmp = 0;
	while(x_tmp < game->max_x)
	{
		y_tmp = 0;
		while (y_tmp < game->max_y)
		{

			if (valid_position(game, x_tmp, y_tmp))
			{
				game->grid[x_tmp][y_tmp] = player;
				if (mini_max(ft_vs(player), 0, game) == 1)
					return ;
				game->grid[x_tmp][y_tmp] = ft_vs(player);
				tmp = mini_max(player, game->ia_lvl, game);
					printf("prob = %d joueur : %d pose x : %d pose : Y %d \n ", tmp, player, x_tmp + 1, y_tmp + 1);
				if (max <= tmp)
				{
					x = x_tmp;
					y = y_tmp;
					max = tmp;
				}
				game->grid[x_tmp][y_tmp] = 0;
			}
			y_tmp++;
		}
		x_tmp++;
	}
	game->grid[x][y] = player;
}
