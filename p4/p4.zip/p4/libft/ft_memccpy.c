/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memccpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alegay <alegay@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/19 14:16:22 by alegay            #+#    #+#             */
/*   Updated: 2013/12/01 15:31:58 by alegay           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "includes/libft.h"

void	*ft_memccpy(void *dest, const void *src, int c, size_t n)
{
	unsigned int	i;

	if (src == NULL)
		return (NULL);
	i = 0;
	while (((char *)src)[i] != c && i < n)
	{
		((char *)dest)[i] = ((char *)src)[i];
		i++;
	}
	if (i == n)
		return (NULL);
	((char *)dest)[i] = ((char *)src)[i];
	return (&((char *)dest)[i + 1]);
}
