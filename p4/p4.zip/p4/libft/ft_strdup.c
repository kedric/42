/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alegay <alegay@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/20 15:29:41 by alegay            #+#    #+#             */
/*   Updated: 2013/12/17 14:22:21 by alegay           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "includes/libft.h"

char	*ft_strdup(const char *str)
{
	int		len;
	int		i;
	char	*save;

	i = 0;
	len = ft_strlen(str);
	save = (char *)malloc(len + 1);
	while (i < len)
	{
		save[i] = str[i];
		i++;
	}
	save[i] = '\0';
	return (save);
}
