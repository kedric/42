/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strtrim.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alegay <alegay@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/24 18:59:46 by alegay            #+#    #+#             */
/*   Updated: 2013/11/24 18:59:47 by alegay           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "includes/libft.h"

char	*ft_strtrim(char const *s)
{
	char	*a;
	int		y;
	int		i;
	int		start;

	i = 0;
	if (s == NULL)
		return (NULL);
	y = ft_strlen(s);
	while (s[i] == ' ' || s[i] == '\t' || s[i] == '\n')
		i++;
	while ((s[y - 1] == ' ' || s[y - 1] == '\t' || s[y - 1] == '\n') && y > 0)
		y--;
	start = (i > y) ? 0 : i;
	a = (char *)malloc(y - start + 1);
	if (a == NULL)
		return (NULL);
	i = 0;
	while (i < y - start)
	{
		a[i] = s[start + i];
		i++;
	}
	a[i] = '\0';
	return (a);
}
