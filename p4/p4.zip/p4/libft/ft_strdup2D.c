/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup2D.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alegay <alegay@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/25 16:31:41 by alegay            #+#    #+#             */
/*   Updated: 2013/12/28 10:37:17 by alegay           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "includes/libft.h"

char	**ft_strdup2D(char **dest, char **src)
{
	int		i;

	i = 0;
	if (src)
	{
		while (src[i])
			i++;
		dest = (char **) malloc((sizeof(char *) * i) + 1);
		if (dest == NULL)
			ft_putendl_fd("Malloc env fail", 2);
		i = 0;
		while (src[i])
		{
			dest[i] = ft_strdup(src[i]);
			i++;
		}
		return (dest);
	}
	return (NULL);
}
