/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strsplit.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alegay <alegay@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/28 10:42:22 by nguezell          #+#    #+#             */
/*   Updated: 2014/02/06 13:31:13 by alegay           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "includes/libft.h"

char	*ft_strsub(char const *s, unsigned int start, size_t len);

int		ft_section(char const *s, char c)
{
	int	i;
	int	section;

	i = 0;
	section = 1;
	if (s == NULL)
		return (-1);
	while (s[i] == c && s[i] != '\0')
		i++;
	if (s[i] == '\0')
		return (-1);
	while (s[i] != c && s[i] != '\0')
		i++;
	while (s[i] != '\0')
	{
		if (s[i] != c)
			section++;
		while (s[i] != c && s[i] != '\0')
			i++;
		if (s[i] != '\0')
			i++;
	}
	return (section);
}

char	**ft_strsplit1(char const *s, char c, int section, size_t len)
{
	char			**split;
	int				i;
	int				j;
	unsigned int	start;

	i = 0;
	split = malloc(sizeof(char *) * (section + 100));
	split[section] = NULL;
	j = 0;
	while (j < section)
	{
		len = 0;
		while (s[i] == c && s[i] != '\0')
			i++;
		start = i;
		while (s[i] != c && ++len && s[i] != '\0')
			i++;
		split[j] = ft_strsub(s, start, len);
		j++;
	}
	return (split);
}

char	**ft_strsplit(char const *s, char c)
{
	int				section;
	char			**split;
	size_t			len;

	len = 0;
	if (!s)
		return (NULL);
	if (s[0] == '\0')
		return (NULL);
	section = ft_section(s, c);
	if (section == -1)
	{
		split = malloc(sizeof(char *) * 2);
		split[0] = NULL;
		split[1] = '\0';
		return (split);
	}
	return (ft_strsplit1(s, c, section, len));
}
