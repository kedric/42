/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alegay <alegay@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/24 18:42:38 by alegay            #+#    #+#             */
/*   Updated: 2013/11/24 18:42:38 by alegay           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "includes/libft.h"

char	*ft_strjoin(char const *s1, char const *s2)
{
	unsigned int	lens2;
	char			*a;
	unsigned int	i;

	i = 0;
	if (s1 == NULL || s2 == NULL)
		return (NULL);
	lens2 = ft_strlen(s2);
	a = (char *)malloc(ft_strlen(s1) + lens2 + 1);
	if (a == NULL)
		return (NULL);
	while (i < ft_strlen(s1))
	{
		a[i] = s1[i];
		i++;
	}
	i = 0;
	while (i < lens2)
	{
		a[ft_strlen(s1) + i] = s2[i];
		i++;
	}
	a[lens2 + ft_strlen(s1)] = '\0';
	return (a);
}
