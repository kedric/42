/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alegay <alegay@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/21 11:08:08 by alegay            #+#    #+#             */
/*   Updated: 2013/11/21 11:08:09 by alegay           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "includes/libft.h"

char		*ft_strstr(const char *dest, const char *src)
{
	int		i;
	int		y;
	int		u;

	i = 0;
	if (src[0] == '\0')
		return (((char *)dest));
	while (dest[i])
	{
		y = 0;
		if (dest[i] == src[0])
		{
			u = i;
			y = 0;
			while (dest[u] && src[y] && dest[u] == src[y])
			{
				u++;
				y++;
			}
			if (dest[u - 1] == src[y - 1] && !(src[y]))
				return (&((char *)dest)[i]);
		}
		i++;
	}
	return (NULL);
}
