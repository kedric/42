/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memset.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alegay <alegay@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/19 11:28:19 by alegay            #+#    #+#             */
/*   Updated: 2013/11/20 17:23:09 by alegay           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "includes/libft.h"

void	*ft_memset(void *ptr, int value, size_t num)
{
	unsigned int	i;

	i = 0;
	while (i < num)
	{
		((char *)ptr)[i] = value;
		i++;
	}
	return (ptr);
}
