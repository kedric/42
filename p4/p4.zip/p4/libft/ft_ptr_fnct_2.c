/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ptr_fnct_2.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alegay <alegay@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/21 17:51:46 by alegay            #+#    #+#             */
/*   Updated: 2014/01/03 11:30:22 by alegay           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "includes/libft.h"

int		ft_printf_x_va(va_list ap)
{
	return (ft_printf_x(va_arg(ap, unsigned int)));
}

int		ft_printf_X_va(va_list ap)
{
	return (ft_printf_X(va_arg(ap, unsigned int)));
}

int		ft_printf_d_va(va_list ap)
{
	return (ft_printf_d(va_arg(ap, int)));
}

int		ft_printf_per100_va(va_list ap)
{
	ap = ap + 0;
	return (ft_printf_c('%'));
}
