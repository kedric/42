/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jmancero <jmancero@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/03/07 23:16:53 by jmancero          #+#    #+#             */
/*   Updated: 2014/03/09 13:27:41 by jmancero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "puissance.h"

void	drow_line(int y, int first)
{
	int i;

	i = 0;
	ft_putstr("\n  ");
	while (i < y && first == 0)
	{
		ft_putstr("____");
		i++;
	}
	while (i < y && first == 1)
	{
		ft_putnbr(i + 1);
		ft_putchar(' ');
		i++;
	}
	ft_putstr("\n");
}

void	print_grid(t_game *game)
{
	int	x;
	int	y;

	x = 0;
	y = 0;
	drow_line(game->max_y, 1);
	while (x < game->max_x)
	{
		y = 0;
		ft_putnbr(x + 1);
		while (y < game->max_y)
		{
			ft_putstr(" | ");
			if (game->grid[x][y] == RED)
				ft_putchar('0');
			else if (game->grid[x][y] == BLUE)
				ft_putchar('x');
			else if (game->grid[x][y] == 0)
				ft_putchar(' ');
			y++;
		}
		ft_putstr(" |");
		drow_line(game->max_y, 0);
		x++;
	}
}

void	ft_print_winner(int winner)
{
	ft_putstr("And the winner is :");
	if (winner == BLUE)
		ft_putstr("X \n");
	if (winner == RED)
		ft_putstr("0 \n");
	if (winner == EGAL)
		ft_putstr(" egaliter\n");
}

void play(int player, t_game *game)
{
	game->player_in = player;
	if (player == 1)
		ia(player, game);
	else
		ft_manage_game(&(game->grid), player);
}

int		ft_play(int ***tab, int column, int player, int ligne)
{
	int		i;

	i = 0;
	while (i < ligne && (*tab)[i][column] == 0)
		i++;
	i--;
	if (i >= 0)
	{
		(*tab)[i][column] = player;
		return(i);
	}
	return (-1);
}

int		ft_check_valid_entry(char *line, int column)
{
	int		i;

	i = 0;
	while (line && line[i])
	{
		if (!ft_isdigit(line[i++]))
			return (0);
	}
	i = ft_atoi(line);
	if (i < 1 || i > column)
		return (0);
	return (i);
}

int		ft_game(int ***tab, char *line, int column, int player)
{
	int		play_col;
	int		play_lin;
	int		ligne;
	t_game	*lol;

	lol = init_game();
	ligne = lol->max_x;
	if ((play_col = ft_check_valid_entry(line, column)))
	{
		if ((play_lin = ft_play(tab, play_col - 1, player, ligne)) != -1)
			return (0);
	}
	return (1);
}


int		ft_manage_game(int ***tab, int player)
{
	char	*line;
	int		column;
	t_game	*lol = init_game();

	column = lol->max_y;
	line = NULL;
	printf("choose a valid column between 1 and %d\n", column);
	while (check_winner() == 0 && get_next_line(0, &line))
	{
		if (ft_game(tab, line, column, player) == 0)
			return (0);
		printf("choose a valid column between 1 and %d\n", column);
		free(line);
	}
	return (0);
}


int	main(int ac, char **av)
{
	t_game *game;
	int player = RED;

	if (ac != 4)
		return (0);
	game = init_game();
	init_grid(av[1], av[2], game);
	while (check_winner() == 0)
	{
		play((player = ft_vs(player)), game);
		print_grid(game);
	}
	ft_print_winner(check_winner());
	return(0);
}
